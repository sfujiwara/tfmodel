# -*- coding: utf-8 -*-

import vgg

__author__ = "Shuhei Fujiwara"
__version__ = "0.1.0"
__license__ = "MIT"
